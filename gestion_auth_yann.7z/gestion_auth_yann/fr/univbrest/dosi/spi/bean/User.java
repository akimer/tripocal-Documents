package fr.univbrest.dosi.spi.bean;

import org.springframework.stereotype.Component;

@Component
public class User {

	public enum Role {
		ADMIN, AUCUN, ETUDIANT, PROF
	}

	private String pwd;
	private Role role = Role.AUCUN;
	private String username;

	/**
	 * @return the pwd
	 */
	public String getPwd() {
		return this.pwd;
	}

	/**
	 * @return the role
	 */
	public Role getRole() {
		return this.role;
	}

	/**
	 * @return the username
	 */
	public String getUsername() {
		return this.username;
	}

	/**
	 * @param pwd
	 *            the pwd to set
	 */
	public void setPwd(final String pwd) {
		this.pwd = pwd;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(final Role role) {
		this.role = role;
	}

	/**
	 * @param username
	 *            the username to set
	 */
	public void setUsername(final String username) {
		this.username = username;
	}
}
