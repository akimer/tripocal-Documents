package fr.univbrest.dosi.spi.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import fr.univbrest.dosi.spi.bean.Enseignant;
import fr.univbrest.dosi.spi.bean.User;
import fr.univbrest.dosi.spi.bean.User.Role;
import fr.univbrest.dosi.spi.exception.SpiException;
import fr.univbrest.dosi.spi.exception.SpiExceptionCode;
import fr.univbrest.dosi.spi.service.EnseignantService;

/**
 * Controller REST pour le service de gestion des enseignant Accessible via le path /enseignant
 *
 * @author ypauly
 */
@RestController
@RequestMapping("/enseignant")
public class EnseignantController {

	private enum TypeDroit {
		CREATE, DELETE, MODIFY, SELECT,
	}

	/**
	 * Service de gestion des enseignants
	 */
	@Autowired
	EnseignantService ensService;

	private final Map<TypeDroit, List<Role>> mapDroits = new HashMap<EnseignantController.TypeDroit, List<Role>>();

	/**
	 * User
	 */
	@Autowired
	User user;

	public EnseignantController() {
		this.configure();
	}

	private void checkDroits(final TypeDroit typeDroit) {
		if (!this.mapDroits.get(typeDroit).contains(this.user.getRole())) {
			throw new SpiException(SpiExceptionCode.NOT_ENOUGH_RIGHT, "L'utilisateur n'a pas les droits suffisants pour effectuer l'action demandée");
		}
	}

	private void configure() {
		this.mapDroits.put(TypeDroit.CREATE, Arrays.asList(Role.ADMIN, Role.PROF));
		this.mapDroits.put(TypeDroit.SELECT, Arrays.asList(Role.ETUDIANT, Role.ADMIN, Role.PROF));
		this.mapDroits.put(TypeDroit.MODIFY, Arrays.asList(Role.ADMIN, Role.PROF));
		this.mapDroits.put(TypeDroit.DELETE, Arrays.asList(Role.ADMIN));
	}

	/**
	 * Service de cration d'un enseignant
	 *
	 * @param enseignant
	 *            l'enseignant à créer
	 * @return lenseignant tel qu'il a été créé
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody Enseignant create(@RequestBody final Enseignant enseignant) {
		this.checkDroits(TypeDroit.CREATE);
		return this.ensService.create(enseignant);
	}

	/**
	 * Service de suppression d'un enseignant
	 *
	 * @param enseignant
	 *            l'enseignant à supprimer
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
	public void delete(@RequestBody final Enseignant enseignant) {
		this.checkDroits(TypeDroit.DELETE);
		this.ensService.delete(enseignant);
	}

	/**
	 * Service récupérant l'ensembl des enseignants
	 *
	 * @return la liste complète des enseignants
	 */
	@RequestMapping(value = "/retrieveAll", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Enseignant> retrieveAll() {
		this.checkDroits(TypeDroit.SELECT);
		return this.ensService.retrieveAll();
	}

	/**
	 * Service de récupération d'un enseignant par son ID
	 *
	 * @param id
	 *            l'identifiant de l'enseignant à récupérer
	 * @return l'enseignant correspondant ou null s'il n'y en a pas
	 */
	@RequestMapping(value = "/searchBy/id/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Enseignant searchById(@PathVariable("id") final Integer id) {
		this.checkDroits(TypeDroit.SELECT);
		return this.ensService.retrieveById(id);
	}

	/**
	 * Service récupérant la liste des enseignants correspondant à un nom donné
	 *
	 * @param name
	 *            le nom des enseignants à rechercher
	 * @return la liste des enseignants correspondants.
	 */
	@RequestMapping(value = "/searchBy/nom/{name}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Enseignant> searchById(@PathVariable("name") final String name) {
		this.checkDroits(TypeDroit.SELECT);
		return this.ensService.retrieveByName(name);
	}

	/**
	 * Service modifiant un enseignant
	 *
	 * @param enseignant
	 *            l'enseignant à modifer avec les nouvelles valeurs renseignées
	 * @return l'enseignant tel qu'il a été enregistré en base
	 */
	// @RequestMapping(value = "/updateenseignant", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE })
	// public @ResponseBody Enseignant update(@RequestBody final Enseignant enseignant) {
	// return this.ensService.modify(enseignant);
	// }
	//
	@RequestMapping(value = "/updateenseignant", method = RequestMethod.POST, headers = "Accept=application/json")
	public Enseignant updateEnseignant(@RequestBody final Enseignant enseignant) {
		this.checkDroits(TypeDroit.MODIFY);
		return this.ensService.modify(enseignant);
	}
}
