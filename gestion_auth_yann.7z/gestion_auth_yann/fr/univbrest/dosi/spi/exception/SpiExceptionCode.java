package fr.univbrest.dosi.spi.exception;

/**
 * Enumération contenant les différents types d'exception remontée dans l'application
 *
 * @author ypauly
 */
public enum SpiExceptionCode {
	CLE_DEJA_EXISTANTE, CLE_INEXISTANTE, NOT_ENOUGH_RIGHT,
}
