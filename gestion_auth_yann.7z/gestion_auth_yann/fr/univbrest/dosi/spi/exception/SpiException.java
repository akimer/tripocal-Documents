package fr.univbrest.dosi.spi.exception;

/**
 * Exception utilisée dans le cadre de l'application SPI
 *
 * @author ypauly
 */
public class SpiException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 8707473705146483637L;
	/**
	 * Code de l'exception, pour avoir facilement une idée générale de ce qui l'a causé.
	 */
	private SpiExceptionCode codeException;

	/**
	 * Construit une exception SPI avec un message {@code null} La cause n'est pas initialisée, mais peut l'être à posteriori en appellant {@link #initCause}.
	 */
	public SpiException() {
		super();
	}

	/**
	 * Construit une nouvelle exception SPI avec le message donné. La cause n'est pas initialisée, mais peut l'être à posteriori en appellant {@link #initCause}.
	 *
	 * @param message
	 *            Le message. Il sera accessible avec la méthode {@link #getMessage()}..
	 */
	public SpiException(final SpiExceptionCode code, final String message) {
		super(message);
		this.codeException = code;
	}

	/**
	 * Construit une nouvelle exception SPI avec le message et la cause donnés
	 *
	 * @param message
	 *            Le message. Il sera accessible avec la méthode {@link #getMessage()}.
	 * @param cause
	 *            la cause (accessible avec la méthode {@link #getCause()}). Null est autorisé pour indiquer que la cause est inconnue ou qu'il n'y en a pas.
	 */
	public SpiException(final SpiExceptionCode code, final String message, final Throwable cause) {
		super(message, cause);
		this.codeException = code;
	}

	/**
	 * Construit une exception SPI avec une cause spécifique et un message valorisé avec l'expression suivante : <tt>(cause==null ? null : cause.toString())</tt>
	 * <p>
	 * Ce constructeur est principalement utilisé pour les exceptions qui ne servent que de wrapper.
	 *
	 * @param cause
	 *            la cause (accessible avec la méthode {@link #getCause()}). Null est autorisé pour indiquer que la cause est inconnue ou qu'il n'y en a pas.
	 */
	public SpiException(final SpiExceptionCode code, final Throwable cause) {
		super(cause);
		this.codeException = code;
	}

	/**
	 * @return the codeException
	 */
	public SpiExceptionCode getCodeException() {
		return this.codeException;
	}

	/**
	 * @param codeException
	 *            the codeException to set
	 */
	public void setCodeException(final SpiExceptionCode codeException) {
		this.codeException = codeException;
	}
}
