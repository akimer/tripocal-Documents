--
--  Cr�ation du jeu d'essai de la table ENSEIGNANT
--

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('1','MCF','H','Saliou','Philippe','6 rue de l''Argoat','29860','LE DRENNEC','FR','06.29.24.01.00','02.98.01.69.74','philippe.saliou@univ-brest.fr','philippe.saliou@gmail.com');

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('2','MCF','H','Lallali','Mounir','18rue Jean Jaur�s','29200','BREST','FR','06.32.03.56.32','02.08.01.67.32','mounir.lallali@univ-brest.fr','mouni.lallali@gmail.com');

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('3','PRAST','H','Bourel','Guillaume','45 rue de SIAM','29200',' BREST','FR','06.21.76.89.28',null,'guillaume.bourel@univ-brest.fr',null);

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('4','INT','H','Le Roux','Pierre','65 route de Gouesnou','29200','BREST','FR','06.45.95.47.29',null,'pierre.leroux@univ-brest.fr','pileroux@gmail.com');

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('5','MCF','H','Kerboeuf','Micka�l','63 rue de la Lib�ration','29650','ST RENAN','FR','06.32.06.84.10',null,'mickael.kerboeuf@univ-brest.fr','mickael.kerboeuf@gmail.com');

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('6','INT','H','Ol�o','Fran�ois','65 rue Charles de Gaule','29260','LESNEVEN','FR','06.31.59.20.43',null,'francois.oleo@univ-brest.fr',null);

Insert into ENSEIGNANT (NO_ENSEIGNANT,TYPE,SEXE,NOM,PRENOM,ADRESSE,CODE_POSTAL,VILLE,PAYS,MOBILE,TELEPHONE,EMAIL_UBO,EMAIL_PERSO) 
values ('7','INT','H','Uguen','Denis','73 Avenue Le Dantec','29200','BREST','FR','06.42.20.30.13',null,'denis.uguen@univ-brest.fr',null);
