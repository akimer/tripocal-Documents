--
--  Cr�ation du jeu d'essai de la table FORMATION
--

Insert into FORMATION (CODE_FORMATION,DIPLOME,N0_ANNEE,NOM_FORMATION,DOUBLE_DIPLOME,DEBUT_ACCREDITATION,FIN_ACCREDITATION) 
values ('M2DOSI','M','2','Master D�veloppement � l''Offshore des Syst�mes d''Information','O',to_date('01/09/12','DD/MM/RR'),to_date('30/09/17','DD/MM/RR'));

Insert into FORMATION (CODE_FORMATION,DIPLOME,N0_ANNEE,NOM_FORMATION,DOUBLE_DIPLOME,DEBUT_ACCREDITATION,FIN_ACCREDITATION) 
values ('M1TIIL','M','1','Master technologie de l''Information et Ing�nierie du Logiciel','N',to_date('01/09/12','DD/MM/RR'),to_date('30/09/17','DD/MM/RR'));

Insert into FORMATION (CODE_FORMATION,DIPLOME,N0_ANNEE,NOM_FORMATION,DOUBLE_DIPLOME,DEBUT_ACCREDITATION,FIN_ACCREDITATION) 
values ('M2TIIL','M','2','Master technologie de l''Information et Ing�nierie du Logiciel','N',to_date('01/09/12','DD/MM/RR'),to_date('30/09/17','DD/MM/RR'));

Insert into FORMATION (CODE_FORMATION,DIPLOME,N0_ANNEE,NOM_FORMATION,DOUBLE_DIPLOME,DEBUT_ACCREDITATION,FIN_ACCREDITATION) 
values ('M2LSE','M','2','Master Logiciel pour Syst�me Embarqu�','N',to_date('01/09/12','DD/MM/RR'),to_date('30/09/17','DD/MM/RR'));
