-- 
-- Script de suppression des tables "journal" du CSCI-ADM
-- Ph. Saliou 
--
DROP TABLE "ENSEIGNANT_JN" CASCADE CONSTRAINTS;

