-- 
-- Script de suppression des VIEW du CSCI-ADM
-- Ph. Saliou - 04 octobre 2012 - 
--

drop view V_DIPLOME;
drop view V_LISTE_SELECTION;
drop view V_OUI_NON;
drop view V_PAYS;
drop view V_PROCESSUS_STAGE;
drop view V_SALLE;
drop view V_SEMESTRE;
drop view V_SEXE;
drop view V_TYPE_ENSEIGNANT;
drop view V_UNIVERSITE;
