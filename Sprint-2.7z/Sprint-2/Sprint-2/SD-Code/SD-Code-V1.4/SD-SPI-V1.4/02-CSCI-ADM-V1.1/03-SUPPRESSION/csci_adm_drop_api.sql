-- 
-- Script de suppression des API de table du CSCI-ADM
-- Ph. Saliou 
--

PROMPT Suppression API de table AUTHENTIFICATION
drop package CG$AUTHENTIFICATION;
drop trigger CG$ADS_AUTHENTIFICATION;
drop trigger CG$AIS_AUTHENTIFICATION;
drop trigger CG$AUS_AUTHENTIFICATION;
drop trigger CG$BDR_AUTHENTIFICATION;
drop trigger CG$BDS_AUTHENTIFICATION;
drop trigger CG$BIR_AUTHENTIFICATION;
drop trigger CG$BIS_AUTHENTIFICATION;
drop trigger CG$BUR_AUTHENTIFICATION;
drop trigger CG$BUS_AUTHENTIFICATION;

