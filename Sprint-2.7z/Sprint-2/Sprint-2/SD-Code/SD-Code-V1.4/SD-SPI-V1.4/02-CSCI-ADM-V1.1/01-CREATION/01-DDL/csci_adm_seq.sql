-- C:\Temp\csci_adm.sqs
--
-- Generated for Oracle 10g on Mon Jan 19  14:05:32 2015 by Server Generator 10.1.2.11.12
 
PROMPT Creating Sequence 'ENS_SEQ'
CREATE SEQUENCE ENS_SEQ
 INCREMENT BY 1
 START WITH 1000
 NOMAXVALUE
 NOMINVALUE
 NOCYCLE
/

