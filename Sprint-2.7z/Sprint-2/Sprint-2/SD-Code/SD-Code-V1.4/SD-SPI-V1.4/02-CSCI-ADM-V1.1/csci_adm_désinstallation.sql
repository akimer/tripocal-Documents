-- 
-- Script de suppression du CSCI-ADM
--	

-- Suppression des API de table
@@03-SUPPRESSION\csci_adm_drop_api

-- Suppression des objets DDL
@@03-SUPPRESSION\csci_adm_drop_vw
@@03-SUPPRESSION\csci_adm_drop_tab
@@03-SUPPRESSION\csci_adm_drop_jn
@@03-SUPPRESSION\csci_adm_drop_seq
