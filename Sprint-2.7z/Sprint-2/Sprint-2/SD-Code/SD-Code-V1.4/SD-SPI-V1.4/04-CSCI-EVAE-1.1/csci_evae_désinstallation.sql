-- 
-- Script de suppression du CSCI-EVAE
-- Ph. Saliou - 17 janvier 2014
--	
-- Suppression des API de table
@@03-SUPPRESSION\csci_evae_drop_api

-- Suppression des objets DDL
@@03-SUPPRESSION\csci_evae_drop_vw
@@03-SUPPRESSION\csci_evae_drop_tab
@@03-SUPPRESSION\csci_evae_drop_seq


