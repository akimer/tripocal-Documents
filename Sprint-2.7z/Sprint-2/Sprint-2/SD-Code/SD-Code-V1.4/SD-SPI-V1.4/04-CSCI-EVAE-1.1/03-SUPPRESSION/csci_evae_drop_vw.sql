-- 
-- Script de suppression des VIEW du CSCI-EVAE
-- Ph. Saliou - 17 janvier 2014 
--

drop view V_ETAT_EVALUATION;
drop view V_POSITIONNEMENT;


