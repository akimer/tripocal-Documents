-- 
-- Script de suppression des s�quences du CSCI-EVAE
-- Ph. Saliou - 17 janvier 2014
--

drop sequence "DRT_SEQ";
drop sequence "EVE_SEQ";
drop sequence "QEV_SEQ";
drop sequence "QUA_SEQ";
drop sequence "QUE_SEQ";
drop sequence "REV_SEQ";
drop sequence "RPE_SEQ";
drop sequence "RUB_SEQ";


