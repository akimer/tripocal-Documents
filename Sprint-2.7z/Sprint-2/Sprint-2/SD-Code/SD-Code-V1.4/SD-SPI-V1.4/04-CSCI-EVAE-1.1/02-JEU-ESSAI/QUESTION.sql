--
--  Cr�ation du jeu d'essai de la table QUESTION
--

Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'1','Contenu');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'2','Int�r�t');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'8','Assimilit� (Ce cours est-il facile � assimiler ?)');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'3','Support de cours');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'4','Rythme');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'13','Nombre de s�ances');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'5','Attention, participation des �tudiants');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'6','Clart� de l''enseignant');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'7','Comp�tence de l''enseignant (vis-�-vis) du domaine)');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'7','Utilitt� des TD pour assimiler le cours');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'6','Niveau des exercices');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'6','Clart� des �nonc�s');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'10','Utilit� des TPpour assimiler le cours');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'9','Explications individuelles');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'8','Difficult� du sujet');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'10','Utilit� du projet pour assimiler le cours');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'2','Int�r�t personnel');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'11','Impression g�n�rale');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'2','Investissement personnel');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'2','Int�r�t � priori pour cet enseignement');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'2','Int�r�t � post�riori pour cet enseignement');
Insert into QUESTION (ID_QUESTION,TYPE,NO_ENSEIGNANT,ID_QUALIFICATIF,INTITULE) values (null,'QUS',null,'12','Volume global horaire');
