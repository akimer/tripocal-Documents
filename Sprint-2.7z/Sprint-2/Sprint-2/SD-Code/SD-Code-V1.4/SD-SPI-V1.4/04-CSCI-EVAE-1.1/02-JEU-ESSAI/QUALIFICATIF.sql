--
--  Cr�ation du jeu d'essai de la table QUALIFICATIF
--
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Pauvre','Riche');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Faible','Fort');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Insatisfaisant','Satisfaisant');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Lent','Rapide');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Faible','Active');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Peu clair','Tr�s clair');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Faible','Forte');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Facile','Difficile');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Insuffisant','Suffisant');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Faible','Importante');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Mauvaise','Bonne');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Insuffisant','Excessif');
Insert into QUALIFICATIF (ID_QUALIFICATIF,MAXIMAL,MINIMAL) values (null,'Insuffisant','Trop nombreux');
