--
--  Cr�ation du jeu d'essai de la table REPONSE_EVALUATION
--
Insert into REPONSE_EVALUATION (ID_REPONSE_EVALUATION,ID_EVALUATION,NO_ETUDIANT,COMMENTAIRE,NOM,PRENOM) values (null,'1','21406919','Une p�dagogie active tr�s int�ressante',null,null);
Insert into REPONSE_EVALUATION (ID_REPONSE_EVALUATION,ID_EVALUATION,NO_ETUDIANT,COMMENTAIRE,NOM,PRENOM) values (null,'1','21406961','Cette UE a permis de consolider nos connaissances en BDD',null,null);
Insert into REPONSE_EVALUATION (ID_REPONSE_EVALUATION,ID_EVALUATION,NO_ETUDIANT,COMMENTAIRE,NOM,PRENOM) values (null,'1','21406956','Il est tr�s int�ressant d''�tre immerg� dans une Tierce Maintenance Applicative',null,null);
