-- 
-- Script de suppression du CSCI-GLOB
-- Ph. Saliou - 04 octobre 2012 - 
--	

-- Suppression des API de table
@@03-SUPPRESSION\csci_glob_drop_api

-- Suppression des tables
@@03-SUPPRESSION\csci_glob_drop_tab;

-- Suppression des sequences
@@03-SUPPRESSION\csci_glob_drop_seq;

-- Suppression des packages PLSQL
@@03-SUPPRESSION\csci_glob_drop_plsql;


