-- 
-- Script de suppression des packages du CSCI-GLOB
-- Ph. Saliou - 04 octobre 2012 - 

drop package CG$ERRORS;
