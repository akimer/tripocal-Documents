-- 
-- Script de suppression des API des tables du CSCI_GLOB
-- Ph. Saliou 
--
PROMPT Suppression API de table CG_REF_CODES
drop package CG$CG_REF_CODES;
drop trigger CG$ADS_CG_REF_CODES;
drop trigger CG$AIS_CG_REF_CODES;
drop trigger CG$AUS_CG_REF_CODES;
drop trigger CG$BDR_CG_REF_CODES;
drop trigger CG$BDS_CG_REF_CODES;
drop trigger CG$BIR_CG_REF_CODES;
drop trigger CG$BIS_CG_REF_CODES;
drop trigger CG$BUR_CG_REF_CODES;
drop trigger CG$BUS_CG_REF_CODES;


