-- 
-- Script de suppression des s�quences du CSCI-ADM
-- Ph. Saliou 
--

drop sequence "CGRC_SEQ";
drop sequence "AUT_SEQ";
