-- C:\Temp\05-SPI-Sprint-1\SD-Code\SD-SPI-V1.1\01-CSCI-GLOB-V1.0\01-CREATION\01-DDL\csci_glob.sqs
--
-- Generated for Oracle 10g on Fri Feb 27  16:08:09 2015 by Server Generator 10.1.2.11.12
 
PROMPT Creating Sequence 'CGRC_SEQ'
CREATE SEQUENCE CGRC_SEQ
 NOMAXVALUE
 NOMINVALUE
 NOCYCLE
/

PROMPT Creating Sequence 'AUT_SEQ'
CREATE SEQUENCE AUT_SEQ
 NOMAXVALUE
 NOMINVALUE
 NOCYCLE
/

